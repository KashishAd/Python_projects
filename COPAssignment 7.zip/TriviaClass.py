#Name: Kashish Adlakha
#U-number: U31221034
#Description: This program shows a class for the Trivia game which has 6 attribute.

class Trivia:
    def __init__(self, q, a1, a2, a3, a4, n):
        self.__question=q
        self.__ans1=a1
        self.__ans2=a2
        self.__ans3=a3
        self.__ans4=a4
        self.__correct=n
    
    def getQuestion(self):
        return self.__question
    def setQuestion(self, q):
        self.__question=q
    def getAnswer1(self):
        return self.__ans1
    def setAnswer1(self, a1):
        self.__ans1=a1
    def getAnswer2(self):
        return self.__ans2
    def setAnswer2(self, a2):
        self.__ans2=a2
    def getAnswer3(self):
        return self.__ans3
    def setAnswer3(self, a3):
        self.__ans3=a3
    def getAnswer4(self):
        return self.__ans4
    def setAnswer4(self, a4):
        self.__ans4=a4
    def getCorrect(self):
        return self.__correct
    def setCorrect(self, n):
        self.__correct=n
    
    def __str__(self):
        return f'{self.__question}\n1. {self.__ans1}\n2. {self.__ans2}\n3. {self.__ans3}\n4. {self.__ans4}'