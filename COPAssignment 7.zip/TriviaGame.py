#Name: Kashish Adalkha
#U-number: U31221034
#Description: This program imports the questions module that was used to generate and return a list of trivia questions and thus executes the Trivia game between two players awarding them points accordingly. 

from questions import createQuestions

def main():
    questions=createQuestions()
    player1_points=0
    player2_points=0
    for i, q in enumerate(questions):
        if i%2==0:
            print('Question for the first player:')
            print(q)
            ans=int(input('Enter your solution (a number between 1 and 4): '))
            if ans==q.getCorrect():
                print('That is the correct answer.')
                player1_points+=1
            else:
                print(f'That is incorrect. The correct answer is {q.getCorrect()}')
        else:
            print('Question for the second player:')
            print(q)
            ans=int(input('Enter your solution (a number between 1 and 4): '))
            if ans==q.getCorrect():
                print('That is the correct answer.')
                player2_points+=1
            else:
                print(f'That is incorrect. The correct answer is {q.getCorrect()}')
        print()
    
    print(f'The first player earned {player1_points} points.')
    print(f'The second player earned {player2_points} points.')
    if player1_points==player2_points:
        print('It\'s a tie!')
    elif player1_points>player2_points:
        print('The first player wins the game.')
    else:
        print('The second player wins the game.')

if __name__=='__main__':
    main()