#Name: Kashish Adlakha
#U-number: U31221034
#Description: This program creates ten Trivia objects by importing the class Trivia, then displays a function that returns those objects in a list.

from TriviaClass import Trivia

def createQuestions():
    q1=Trivia('How many days are in a lunar year?', 354, 365, 243, 379, 1)
    q2=Trivia('What is the largest planet?', 'Mars', 'Jupiter', 'Earth', 'Pluto', 2)
    q3=Trivia('What is the largest kind of whale?', 'Orca whale', 'Humpback whale', 'Beluga whale', 'Blue whale', 4)
    q4=Trivia('Which dinosaur could fly?', 'Triceratops', 'Tyrannosaurus Rex', 'Pteranodon', 'Diplodocus', 3)
    q5=Trivia('Which of these Winnie the Pooh characters is a donkey?', 'Pooh', 'Eeyore', 'Piglet', 'Kanga', 2)
    q6=Trivia('What is the hottest planet?', 'Mars', 'Pluto', 'Earth', 'Venus', 4)
    q7=Trivia('Which dinosaur had the largest brain compared to body size?', 'Troodon', 'Stegosaurus', 'Ichthyosaurus', 'Gigantoraptor', 1)
    q8=Trivia('What is the largest type of penguins?', 'Chinstrap penguins', 'Macaroni penguins', 'Emperor penguins', 'White-flippered penguins', 3)
    q9=Trivia('Which children\'s story character is a monkey?', 'Winnie the Pooh', 'Curios George', 'Horton', 'Goofy', 2)
    q10=Trivia('How long is a year on Mars?', '550 Earth days', '498 Earth days', '126 Earth days', '687 Earth days', 4)
    return [q1, q2, q3, q4, q5, q6, q7, q8, q9, q10]